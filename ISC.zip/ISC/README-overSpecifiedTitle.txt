filename	journal_id	vol_id	article_id	keyword
016-en.txt	3853	23298	197316	nature salt water electric
017-en.txt	3913	23591	200449	leukemia csf1r blocking myeloma 
018-en.txt	326		64730	622629	geopersia metals metalloids Sari Gunay 
019-en.txt	4170	27218	211788	geo-marine letters Mascle structure belt
020-en.txt	4179	27549	216725	the astronomy and astrophysics review Starspots stellar surface 
021-en.txt	3141	59725	579568	ecopersia morphological Entomacrodus striatus Gulf of Oman 
022-en.txt	3702	22744	191201	addiction disorder twin study DSM-IV 
023-en.txt	4172	27286	212435	living reviews in relativity Kilonovae neutron wave LIGO 
024-en.txt	183		9866	78862	general mathematics notes Soft Graphs uncertainties
025-en.txt	3701	22732	191087	annual review of fluid mechanics Fire whirls research power formation
016-fa.txt	2878	57712	551507	جستارهای تاریخی شب  یلدا چله آذرجشن
017-fa.txt	0423	40640	372401	جستارهای نوین ادبی چرخیات شعر قصیده فارسی
018-fa.txt	2938	14744	120318	پژوهش های دستوری و بلاغی رمان نو  دنیای معاصر
019-fa.txt	4207	31353	262250	مطالعات بین المللی حق تفاوت شهروند فرهنگی
020-fa.txt	0274	18220	150111	حقوق خصوصی حك تصویر حریم خصوصی  حقوق شخصیت قرارداد مرگ
021-fa.txt	1746	36339	311764	علوم و تحقیقات بذر ایران زوال بذر بنیه زنده‌مانی
022-fa.txt	3195	38452	337034	مطالعات زبانی و بلاغی سماع وزن بحور عروضی کلیات شمس  زحافات عروضی
023-fa.txt	2610	54551	521413	دانش حسابرسی سوآپ  قرارداد معاوضه ارز معامله
024-fa.txt	0926	2848	25158	پژوهش های ادب عرفانی حافظ عرفان وقت حال نفس خوش
025-fa.txt	3850	23371	198013	علم زبان تکواژ صفر بافت زبانی غیرزبانی صرف نحو
016-ar.txt	21598	66290	636548	السبط العلمیة المحکمة صفات الطبيعية
017-ar.txt	1673	61553	594555	بحوث في اللغة العربية التکرار الصحيفة السجادية دعاء العرفة
018-ar.txt	0253	64690	622275	اللغة العربیة و آدابها الرومانسيه عباس محمود العقاد
019-ar.txt	0522	59665	579067	فصلية دراسات الادب المعاصر  الأطفال أحمد شوقی سليمان العیسی
020-ar.txt	19075	60110	582560	دراسات فی السردانیة العربیة القصص القرآنية المفسرين الشيعة
021-ar.txt	13834	57506	549734	مجلة کلیة التربیة جامعة واسط ازدواجيه الشخصيه العراقيه 
022-ar.txt	1716	60929	589964	دراسات في اللغة العربية وآدابها المتلازمات اللّفظيّه المعجم اللّغوي 
023-ar.txt	0521	64192	617703	إضاءات نقدیة فی الأدبین العربی و الفارسی عقدة النقص 
024-ar.txt	1673	58829	569789	بحوث في اللغة العربية منهج ابن عصفور المقرّب
025-ar.txt	0253	63019	606136	اللغة العربیة و آدابها الاستغراق خليل الكافر جيرار جنيت
016-ru.txt	0415	2875	25412	issledovatel skiy zhurnal russkogo yazyka i literatury иноязычный элемент национальный язык подъязык диалект просторечие литературный язык социальный диалект
017-ru.txt	0415	2878	25435	issledovatel literatury словесность духовное направление
018-ru.txt	0415	2878	25438	issledovatel skiy zhurnal russkogo yazyka i literatury Тютчев Иванов Ореады гора мифопоэтика символ
019-ru.txt	0415	2874	25404	issledovatel skiy zhurnal russkogo yazyka i literatury Женитьба эмоция страха фольклорные мотивы гендерные стереотипы экзистенция
020-ru.txt	0415	3183	27386	issledovatel skiy zhurnal russkogo yazyka i literatury Футуризм авиация поэтический язык футуристов-авиаторов новый образ мира человек и машина
021-ru.txt	0415	2879	25439	issledovatel skiy zhurnal russkogo yazyka i literatury компьютерный сленг метод сплошной выборки сленгизмы семантическое поле тематические группы
022-ru.txt	0415	2876	25418	issledovatel skiy zhurnal russkogo yazyka i literatury система языка сема динамико-функциональный подход семантический потенциал валентностный потенциал семантическая структура
023-ru.txt	415	2874	25406	issledovatel skiy zhurnal russkogo yazyka i literatury А. Куприн мусульманское происхождение ментальность восточные мотивы восточные ценности фольклор
024-ru.txt	415	2878	25434	issledovatel skiy zhurnal russkogo yazyka i literatury А.К. Толстой историзм баллады роман драмы
025-ru.txt	415	3183	27388	issledovatel skiy zhurnal russkogo yazyka i literatury В. Хлебников мифопоэтика неоромантизм русская идея всеединство